/**
 * Contains Predefined effects for painters.
 */
package org.jdesktop.swingx.painter.effects;

