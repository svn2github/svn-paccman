/**
 * Contains classes used by slider classes, such as {@code JXMultiThumbSlider}.
 */
package org.jdesktop.swingx.multislider;

