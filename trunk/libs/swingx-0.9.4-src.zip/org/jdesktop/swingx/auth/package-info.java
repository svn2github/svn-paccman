/**
 * Contains classes and interfaces used by the {@code JXLoginPane} component.
 */
package org.jdesktop.swingx.auth;

