/**
 * Contains classes and interfaces used by the {@code JErrorPane} component.
 */
package org.jdesktop.swingx.error;

